# Assignment 3 – CO3
**Student:** Rithika K  
**Register Number:** 192421075  
**Course:** C++ / OOP  
**GitHub repository name:** `DSA01-192421075-Assignment3`

## Contents
- `Q1`–`Q7`: one C++ source file per task.
- `output_samples/`: clearly labelled sample outputs generated in the preparation environment.
- `Rithika_K_Assignment3_Report.pdf`: report and design/analysis.
- `Rithika_K_Assignment3_Source_Code.pdf`: source listing.

## Compiler and build
Compiler used for preparation: GNU g++ available in the execution environment (record your exact local version with `g++ --version`).
Compile each file from its task folder with:
```bash
g++ -std=c++17 -Wall -Wextra Q1_Constructors.cpp -o q1
./q1
```
Use the corresponding filename/output executable for each task. For sanitizer checks:
```bash
g++ -std=c++17 -Wall -Wextra -fsanitize=address -fno-omit-frame-pointer Q2_Copy_Constructor_Rule_of_Three.cpp -o q2_asan
./q2_asan
```

## Task result notes
- Q1: constructor overloads, delegation, initializer lists, invalid-copy validation, explicit conversion.
- Q2: deep copy, copy assignment, destructor, independence and self-assignment.
- Q3: dynamic 2D seat allocation, booking/cancellation, stack/heap/block lifetimes.
- Q4: Money arithmetic, comparison and stream insertion/extraction.
- Q5: prefix/postfix increment, comparison and checked playlist subscript.
- Q6: Text class with Rule of Three and overloaded concatenation/comparison/stream output.
- Q7: Complex arithmetic for series/parallel impedance and safe zero division.

## Before submission — mandatory
1. Create the GitHub repository exactly as `DSA01-192421075-Assignment3`.
2. Add one folder per task, containing source, any input, and your **real local execution screenshots**.
3. Add faculty as collaborator if the repository is private.
4. Commit progressively: at least one commit per task; do not upload everything in one final commit.
5. Put the working GitHub URL on the report cover and submission.
6. Replace/add genuine screenshots from your own laptop. The included output images are preparation-environment samples, not screenshots from your computer.
7. Run the required investigations yourself: sanitizer on shallow/deep versions; allocation sizes; prefix/postfix timings at -O0/-O2; Text vs std::string timing; and any compiler warning experiments. Record measured values and exact compiler version. Do not claim sample values as measurements.
8. Verify every task and be ready to explain/defend your design in the viva.

**Important:** Example values and implementation choices in this pack are illustrative where the assignment leaves design choices open. Check your faculty's expectations and understand the code before submission.
