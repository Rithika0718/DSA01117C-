#include <cmath>
#include <iostream>
#include <stdexcept>

class Complex {
    double realPart, imagPart;

public:
    Complex() : realPart(0.0), imagPart(0.0) {}
    Complex(double real) : realPart(real), imagPart(0.0) {}
    Complex(double real, double imag) : realPart(real), imagPart(imag) {}

    double real() const { return realPart; }
    double imag() const { return imagPart; }
    double magnitude() const { return std::hypot(realPart, imagPart); }

    Complex operator+(const Complex& z) const {
        return Complex(realPart + z.realPart, imagPart + z.imagPart);
    }
    Complex operator-(const Complex& z) const {
        return Complex(realPart - z.realPart, imagPart - z.imagPart);
    }
    Complex operator*(const Complex& z) const {
        return Complex(realPart*z.realPart - imagPart*z.imagPart,
                       realPart*z.imagPart + imagPart*z.realPart);
    }
    Complex operator/(const Complex& z) const {
        double denominator = z.realPart*z.realPart + z.imagPart*z.imagPart;
        if (denominator == 0.0)
            throw std::domain_error("division by zero impedance");
        return Complex((realPart*z.realPart + imagPart*z.imagPart)/denominator,
                       (imagPart*z.realPart - realPart*z.imagPart)/denominator);
    }
    bool operator==(const Complex& z) const {
        constexpr double eps = 1e-9;
        return std::abs(realPart-z.realPart) < eps &&
               std::abs(imagPart-z.imagPart) < eps;
    }
    friend std::ostream& operator<<(std::ostream& out, const Complex& z) {
        out << z.realPart;
        if (z.imagPart >= 0) out << " + j" << z.imagPart;
        else out << " - j" << -z.imagPart;
        return out;
    }
};

int main() {
    // Example series RLC impedance at a chosen angular frequency:
    // R=10 ohm, XL=8 ohm, XC=3 ohm -> Z = 10 + j(8-3) = 10+j5.
    Complex resistor(10.0, 0.0);
    Complex inductor(0.0, 8.0);
    Complex capacitor(0.0, -3.0);
    Complex series = resistor + inductor + capacitor;
    std::cout << "Series impedance: " << series
              << " | magnitude=" << series.magnitude() << '\n';

    // Two branch impedances in parallel: (Z1*Z2)/(Z1+Z2).
    Complex z1(10.0, 5.0), z2(20.0, -2.0);
    Complex parallel = (z1 * z2) / (z1 + z2);
    std::cout << "Parallel impedance: " << parallel
              << " | magnitude=" << parallel.magnitude() << '\n';

    try {
        Complex invalid = z1 / Complex();
        std::cout << invalid << '\n';
    } catch (const std::domain_error& e) {
        std::cout << "Safe error: " << e.what() << '\n';
    }
}
