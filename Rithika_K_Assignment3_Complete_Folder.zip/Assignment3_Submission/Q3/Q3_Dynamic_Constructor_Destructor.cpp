#include <iostream>
#include <string>

class Event {
    int rows, seatsPerRow;
    bool** seats;
    int booked;

public:
    Event(int r, int s)
        : rows(r > 0 ? r : 0), seatsPerRow(s > 0 ? s : 0),
          seats(nullptr), booked(0) {
        if (rows > 0 && seatsPerRow > 0) {
            seats = new bool*[rows]{};
            for (int i = 0; i < rows; ++i)
                seats[i] = new bool[seatsPerRow]{};
        }
        std::cout << "Created event " << rows << "x" << seatsPerRow << '\n';
    }

    bool book(int r, int s) {
        if (r < 0 || r >= rows || s < 0 || s >= seatsPerRow || seats[r][s])
            return false;
        seats[r][s] = true;
        ++booked;
        return true;
    }

    bool cancel(int r, int s) {
        if (r < 0 || r >= rows || s < 0 || s >= seatsPerRow || !seats[r][s])
            return false;
        seats[r][s] = false;
        --booked;
        return true;
    }

    ~Event() {
        if (seats) {
            for (int i = 0; i < rows; ++i) delete[] seats[i];
            delete[] seats;
        }
        std::cout << "Closed event; remaining bookings=" << booked << '\n';
    }
};

int main() {
    std::cout << "Stack object:\n";
    Event mainEvent(2, 3);
    mainEvent.book(0, 0);
    mainEvent.book(1, 2);
    mainEvent.cancel(0, 0);

    std::cout << "Heap object:\n";
    Event* heapEvent = new Event(1, 2);
    heapEvent->book(0, 1);
    delete heapEvent;

    std::cout << "Block object:\n";
    {
        Event blockEvent(1, 1);
        blockEvent.book(0, 0);
    }

    std::cout << "Zero-row object:\n";
    Event emptyEvent(0, 5);
}
