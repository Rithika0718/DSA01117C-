#include <iostream>
#include <string>
#include <utility>

class Book {
    std::string title;
    std::string author;
    int copies;

    static int validCopies(int value) {
        if (value < 0) {
            std::cerr << "Negative copies rejected; using 0.\n";
            return 0;
        }
        return value;
    }

public:
    Book() : Book("Untitled", "Unknown", 0) {} // delegated default constructor
    explicit Book(const std::string& bookTitle) : Book(bookTitle, "Unknown", 1) {}
    Book(const std::string& bookTitle, const std::string& bookAuthor, int count)
        : title(bookTitle), author(bookAuthor), copies(validCopies(count)) {}

    void print() const {
        std::cout << title << " | " << author << " | copies=" << copies << '\n';
    }
};

int main() {
    Book empty;
    Book donated("The Alchemist");
    Book full("Wings of Fire", "A. P. J. Abdul Kalam", 4);
    Book invalid("Invalid Record", "Test Author", -3);
    empty.print();
    donated.print();
    full.print();
    invalid.print();

    // explicit prevents implicit conversion from const char* to Book.
    // Book implicitBook = "Dune"; // does not compile because constructor is explicit
    Book directBook("Dune");
    directBook.print();
}
