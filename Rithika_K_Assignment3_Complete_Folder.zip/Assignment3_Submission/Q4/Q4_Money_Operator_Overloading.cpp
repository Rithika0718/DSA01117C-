#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

class Money {
    long long paise;

public:
    Money(long long rupees = 0, int p = 0) : paise(rupees * 100 + p) {}

    Money operator+(const Money& rhs) const {
        return Money(0, static_cast<int>(paise + rhs.paise));
    }
    Money operator-(const Money& rhs) const {
        return Money(0, static_cast<int>(paise - rhs.paise));
    }
    Money& operator+=(const Money& rhs) {
        paise += rhs.paise;
        return *this;
    }
    bool operator==(const Money& rhs) const { return paise == rhs.paise; }
    bool operator<(const Money& rhs) const { return paise < rhs.paise; }

    friend std::ostream& operator<<(std::ostream& out, const Money& value) {
        long long absolute = value.paise < 0 ? -value.paise : value.paise;
        if (value.paise < 0) out << "-";
        return out << "Rs " << absolute / 100 << '.'
                   << std::setw(2) << std::setfill('0') << absolute % 100
                   << std::setfill(' ');
    }
    friend std::istream& operator>>(std::istream& in, Money& value) {
        long long rupees;
        int p;
        if (in >> rupees >> p) value.paise = rupees * 100 + p;
        return in;
    }
};

int main() {
    Money a(120, 75), b(79, 25);
    Money total = a + b;
    std::cout << total << '\n' << std::boolalpha << (total == Money(200)) << '\n';

    Money carry(0, 75);
    carry += Money(0, 50);
    std::cout << "Carry test: " << carry << '\n';

    Money negative = Money(2, 0) - Money(5, 25);
    std::cout << "Negative test: " << negative << '\n';
    std::cout << "Comparison: " << (a < b) << '\n';
}
