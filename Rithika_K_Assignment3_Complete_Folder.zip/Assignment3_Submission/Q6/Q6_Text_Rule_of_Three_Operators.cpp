#include <cstring>
#include <iostream>

class Text {
    char* data;

public:
    explicit Text(const char* s = "") {
        std::size_t n = std::strlen(s);
        data = new char[n + 1];
        std::memcpy(data, s, n + 1);
    }

    Text(const Text& other) {
        std::size_t n = std::strlen(other.data);
        data = new char[n + 1];
        std::memcpy(data, other.data, n + 1);
        std::cout << "[Text copy] ";
    }

    Text& operator=(const Text& other) {
        if (this != &other) {
            std::size_t n = std::strlen(other.data);
            char* fresh = new char[n + 1];
            std::memcpy(fresh, other.data, n + 1);
            delete[] data;
            data = fresh;
        }
        return *this;
    }

    ~Text() { delete[] data; }

    Text operator+(const Text& rhs) const {
        std::size_t left = std::strlen(data), right = std::strlen(rhs.data);
        char* joined = new char[left + right + 1];
        std::memcpy(joined, data, left);
        std::memcpy(joined + left, rhs.data, right + 1);
        Text result(joined);
        delete[] joined;
        return result;
    }

    bool operator==(const Text& rhs) const {
        return std::strcmp(data, rhs.data) == 0;
    }
    bool operator!=(const Text& rhs) const { return !(*this == rhs); }

    friend std::ostream& operator<<(std::ostream& out, const Text& value) {
        return out << value.data;
    }
};

int main() {
    Text first("Hello ");
    Text second("World");
    Text combined = first + second;
    std::cout << "\nCombined: " << combined << '\n';

    Text empty;
    Text assigned("temporary");
    assigned = empty;
    std::cout << "Empty assignment: [" << assigned << "]\n";

    first = first; // self-assignment
    std::cout << "Self assignment: " << first << '\n';
    std::cout << std::boolalpha
              << "Equality: " << (combined == Text("Hello World"))
              << " inequality: " << (first != second) << '\n';
}
