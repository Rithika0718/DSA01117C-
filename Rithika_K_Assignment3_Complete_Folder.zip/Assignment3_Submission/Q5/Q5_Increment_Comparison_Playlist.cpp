#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

class Time {
    int seconds;

public:
    explicit Time(int total = 0) : seconds(total < 0 ? 0 : total) {}
    Time& operator++() { ++seconds; return *this; }          // prefix
    Time operator++(int) { Time old(*this); ++seconds; return old; } // postfix
    bool operator==(const Time& rhs) const { return seconds == rhs.seconds; }
    bool operator<(const Time& rhs) const { return seconds < rhs.seconds; }
    int value() const { return seconds; }
};

class Playlist {
    std::vector<std::string> tracks;

public:
    explicit Playlist(std::vector<std::string> items) : tracks(std::move(items)) {}
    std::string& operator[](int index) {
        if (index < 0 || index >= static_cast<int>(tracks.size()))
            throw std::out_of_range("playlist index out of range");
        return tracks[static_cast<std::size_t>(index)];
    }
    const std::string& operator[](int index) const {
        if (index < 0 || index >= static_cast<int>(tracks.size()))
            throw std::out_of_range("playlist index out of range");
        return tracks[static_cast<std::size_t>(index)];
    }
    int size() const { return static_cast<int>(tracks.size()); }
};

int main() {
    Time t(5);
    Time a = t++;
    Time b = ++t;
    std::cout << "postfix copy=" << a.value()
              << " prefix result=" << b.value()
              << " current=" << t.value() << '\n';

    Playlist playlist({"Track One", "Track Two", "Track Three"});
    std::cout << "Now playing: " << playlist[0] << '\n';
    playlist[1] = "Updated Track";
    std::cout << "Updated: " << playlist[1] << '\n';

    try { std::cout << playlist[-1] << '\n'; }
    catch (const std::out_of_range& e) { std::cout << "Error: " << e.what() << '\n'; }
    try { std::cout << playlist[playlist.size()] << '\n'; }
    catch (const std::out_of_range& e) { std::cout << "Error: " << e.what() << '\n'; }

    Time rollover(3599);
    ++rollover;
    std::cout << "Raw seconds after 59:59 + 1 = " << rollover.value()
              << " (formatting as 1:00:00 is a display-layer responsibility)\n";
}
