#include <iostream>
#include <string>
#include <algorithm>

class Prescription {
    int n;
    std::string* medicines;

public:
    explicit Prescription(int count)
        : n(std::max(0, count)), medicines(n ? new std::string[n] : nullptr) {}

    // Deep-copy constructor
    Prescription(const Prescription& other)
        : n(other.n), medicines(n ? new std::string[n] : nullptr) {
        for (int i = 0; i < n; ++i) medicines[i] = other.medicines[i];
        std::cout << "[copy constructor] copied " << n << " medicines\n";
    }

    // Copy assignment: allocate/copy first, then replace old storage
    Prescription& operator=(const Prescription& other) {
        if (this != &other) {
            std::string* fresh = other.n ? new std::string[other.n] : nullptr;
            for (int i = 0; i < other.n; ++i) fresh[i] = other.medicines[i];
            delete[] medicines;
            medicines = fresh;
            n = other.n;
        }
        return *this;
    }

    ~Prescription() { delete[] medicines; }

    void set(int i, const std::string& medicine) {
        if (i >= 0 && i < n) medicines[i] = medicine;
    }
    std::string get(int i) const {
        return (i >= 0 && i < n) ? medicines[i] : "<out-of-range>";
    }
    int size() const { return n; }
};

void inspectByValue(Prescription p) {
    std::cout << "inspectByValue size=" << p.size() << '\n';
}
void inspectByConstReference(const Prescription& p) {
    std::cout << "inspectByConstReference size=" << p.size() << '\n';
}

int main() {
    Prescription p(2);
    p.set(0, "Paracetamol");
    p.set(1, "ORS");
    Prescription q = p;
    q.set(1, "Cetirizine");
    Prescription r(1);
    r = p;
    p.set(0, "Ibuprofen");
    p = p; // self-assignment is safe

    std::cout << p.get(0) << ' ' << p.get(1) << " | "
              << q.get(0) << ' ' << q.get(1) << " | "
              << r.get(0) << ' ' << r.get(1) << '\n';
    inspectByValue(p);
    inspectByConstReference(p);
}
