ASSIGNMENT 2 – CO2
Student: Rithika K
Register Number: 192421075

Contents:
1. Rithika_K_Assignment2_Report.pdf – assignment answer report
2. Rithika_K_Assignment2_Source_Code.pdf – source code for Q1–Q7
3. Assignment2_Q5_Execution_Sample.png – generated sample execution capture
4. Assignment2_Q7_Execution_Sample.png – generated sample execution capture
5. Rithika_K_Assignment2_Source_Files.zip – individual C++ source files and README

Important:
- The two PNG files are generated sample captures, not screenshots taken from the student's laptop.
- Run the C++ programs locally, capture genuine execution screenshots, and add the working GitHub repository URL to the report before submission.
- Required repository name: DSA01-192421075-Assignment2
