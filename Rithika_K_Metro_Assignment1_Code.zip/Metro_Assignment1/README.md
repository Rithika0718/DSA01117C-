# City Metro Smart-Card Fare System — Assignment 1 (CO1)

**Student name:** Rithika K  
**Register number:** 192421075  
**Compiler:** g++ 14.2.0, C++17  
**GitHub URL:** [PASTE ACTUAL REPOSITORY LINK]  

## Compile and run

From any TaskXX directory, compile a `.cpp` file with:

```bash
g++ -std=c++17 -Wall -Wextra -pedantic filename.cpp -o program
./program
```

For Task08: `./program < input.txt`. Every source was compiled and executed. Each `*_compile.txt` contains the compile command and warning text; each `*_output.txt` contains real stdout and exit code.

## Task results

| Task | Result |
|---|---|
| 01 | Card invariant and OOP object model |
| 02 | Centralized constants and scoped zones |
| 03 | Type sizes, ranges and large collection |
| 04 | Implicit conversions, prediction and corrected alternative |
| 05 | Precedence prediction and peak lookup table |
| 06 | Completed original TODO program and peak boundaries |
| 07 | Procedural and OOP comparison |
| 08 | Invalid input recovery and formatted journey report |
| 09 | Automated fares and boundary tests |
| 10 | Integer versus double accumulation measurements |
| 11 | Recommended encapsulated design |
| 12 | Airport zone, exclusive weekend rule and monthly pass |

## Submission checklist

- [ ] Confirm name/register number.
- [ ] Independently verify the five-trip handwritten total in the report and test file.
- [ ] Capture actual terminal output screenshots for each task.
- [ ] Record pre-execution predictions personally (required by assignment).
- [ ] Create GitHub repository `DSA01-192421075-Assignment1` (adjust number if needed).
- [ ] Make separate genuine commits for each task; do not backdate.
- [ ] Push and paste the actual GitHub link on the report cover.
- [ ] Add faculty as collaborator if private.

**Notes:** The assignment does not specify student/senior concession percentages. Code accepts a validated parameter rather than inventing a fixed policy. Weekend overrides peak; monthly pass covers two distinct zones.
