#include <iostream>
#include <iomanip>
#include <climits>
int main(){for(long long n:{20000LL,500000LL,3000000LL}){long long exact=0;double floating=0;for(long long i=0;i<n;i++){exact+=101;floating+=1.01;}double diff=floating-exact/100.0;std::cout<<std::fixed<<std::setprecision(10)<<"n="<<n<<" paise="<<exact<<" double_Rs="<<floating<<" error_Rs="<<diff<<"\n";}std::cout<<"INT_MAX="<<INT_MAX<<" max_daily_airport_paise="<<3000000LL*6000<<"\n";}
