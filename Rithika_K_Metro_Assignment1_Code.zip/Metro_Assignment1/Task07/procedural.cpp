#include <iostream>
constexpr long long MINIMUM=5000;
bool canTravel(long long balance,long long fare){return fare>=0&&balance>=MINIMUM&&fare<=balance-MINIMUM;}
bool deduct(long long& balance,long long fare){if(!canTravel(balance,fare))return false;balance-=fare;return true;}
int main(){long long balance=6000;std::cout<<deduct(balance,1000)<<" "<<balance<<"\n"<<deduct(balance,1)<<" "<<balance<<"\n";}
