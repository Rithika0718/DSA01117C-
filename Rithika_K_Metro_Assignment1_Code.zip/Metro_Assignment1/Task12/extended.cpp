#include <iostream>
#include <iomanip>
#include <stdexcept>
#include <array>
#include <climits>
using namespace std;
enum class Zone { Inner, Middle, Outer, Airport };
constexpr array<long long,4> BASE{1000,2000,3000,6000};
constexpr long long MIN_BALANCE=5000;
constexpr int PEAK_PERCENT=20;
constexpr int WEEKEND_PERCENT=10;
long long baseFare(Zone z){auto i=static_cast<int>(z);if(i<0||i>=4)throw invalid_argument("Unknown zone");return BASE[i];}
bool peakAt(int hour){if(hour<0||hour>23)throw invalid_argument("Invalid hour");return (hour>=8&&hour<10)||(hour>=17&&hour<20);}
long long fare(Zone z,int hour,bool weekend=false,int concessionPercent=0){if(concessionPercent<0||concessionPercent>100)throw invalid_argument("Invalid concession");long long b=baseFare(z);int factor=weekend?100-WEEKEND_PERCENT:(peakAt(hour)?100+PEAK_PERCENT:100);return (b*factor*(100-concessionPercent)+5000)/10000;}
class SmartCard {long long balance_;public: explicit SmartCard(long long b):balance_(b){if(b<0)throw invalid_argument("Negative balance");}long long balance()const{return balance_;}bool canTravel(long long f)const{return f>=0&&balance_>=MIN_BALANCE&&f<=balance_-MIN_BALANCE;}bool deduct(long long f){if(!canTravel(f))return false;balance_-=f;return true;}bool recharge(long long x){if(x<0||x>LLONG_MAX-balance_)return false;balance_+=x;return true;}};
#include <optional>
#include <string>
class MonthlyPass{Zone first_,second_;bool active_;public:MonthlyPass(Zone a,Zone b,bool active):first_(a),second_(b),active_(active){if(a==b)throw invalid_argument("Choose distinct zones");baseFare(a);baseFare(b);}bool covers(Zone z)const{return active_&&(z==first_||z==second_);}};
long long extendedFare(Zone z,int hour,bool weekend,const MonthlyPass* pass){baseFare(z);if(pass&&pass->covers(z))return 0;return fare(z,hour,weekend);}
int main(){MonthlyPass p(Zone::Inner,Zone::Airport,true);SmartCard c(12000);struct Test{Zone z;int hour;bool weekend;long long expected;};Test tests[]={{Zone::Airport,8,false,0},{Zone::Middle,8,false,2400},{Zone::Outer,8,true,2700},{Zone::Inner,11,false,0},{Zone::Airport,20,true,0},{Zone::Middle,10,false,2000}};int passed=0;for(const auto&t:tests){auto actual=extendedFare(t.z,t.hour,t.weekend,&p);bool ok=actual==t.expected;passed+=ok;cout<<"expected="<<t.expected<<" actual="<<actual<<" "<<(ok?"PASS":"FAIL")<<"\n";}cout<<"pass tests "<<passed<<"/6\n";return passed==6?0:1;}
