#include <iostream>
#include <iomanip>
#include <stdexcept>
#include <array>
#include <climits>
using namespace std;
enum class Zone { Inner, Middle, Outer, Airport };
constexpr array<long long,4> BASE{1000,2000,3000,6000};
constexpr long long MIN_BALANCE=5000;
constexpr int PEAK_PERCENT=20;
constexpr int WEEKEND_PERCENT=10;
long long baseFare(Zone z){auto i=static_cast<int>(z);if(i<0||i>=4)throw invalid_argument("Unknown zone");return BASE[i];}
bool peakAt(int hour){if(hour<0||hour>23)throw invalid_argument("Invalid hour");return (hour>=8&&hour<10)||(hour>=17&&hour<20);}
long long fare(Zone z,int hour,bool weekend=false,int concessionPercent=0){if(concessionPercent<0||concessionPercent>100)throw invalid_argument("Invalid concession");long long b=baseFare(z);int factor=weekend?100-WEEKEND_PERCENT:(peakAt(hour)?100+PEAK_PERCENT:100);return (b*factor*(100-concessionPercent)+5000)/10000;}
class SmartCard {long long balance_;public: explicit SmartCard(long long b):balance_(b){if(b<0)throw invalid_argument("Negative balance");}long long balance()const{return balance_;}bool canTravel(long long f)const{return f>=0&&balance_>=MIN_BALANCE&&f<=balance_-MIN_BALANCE;}bool deduct(long long f){if(!canTravel(f))return false;balance_-=f;return true;}bool recharge(long long x){if(x<0||x>LLONG_MAX-balance_)return false;balance_+=x;return true;}};
int main(){for(int h:{8,10,17,20})cout<<h<<":00 peak="<<peakAt(h)<<" outer fare="<<fare(Zone::Outer,h)<<"\n";}
