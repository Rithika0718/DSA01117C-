#include <iostream>
#include <iomanip>
#include <stdexcept>
#include <array>
#include <climits>
using namespace std;
enum class Zone { Inner, Middle, Outer, Airport };
constexpr array<long long,4> BASE{1000,2000,3000,6000};
constexpr long long MIN_BALANCE=5000;
constexpr int PEAK_PERCENT=20;
constexpr int WEEKEND_PERCENT=10;
long long baseFare(Zone z){auto i=static_cast<int>(z);if(i<0||i>=4)throw invalid_argument("Unknown zone");return BASE[i];}
bool peakAt(int hour){if(hour<0||hour>23)throw invalid_argument("Invalid hour");return (hour>=8&&hour<10)||(hour>=17&&hour<20);}
long long fare(Zone z,int hour,bool weekend=false,int concessionPercent=0){if(concessionPercent<0||concessionPercent>100)throw invalid_argument("Invalid concession");long long b=baseFare(z);int factor=weekend?100-WEEKEND_PERCENT:(peakAt(hour)?100+PEAK_PERCENT:100);return (b*factor*(100-concessionPercent)+5000)/10000;}
class SmartCard {long long balance_;public: explicit SmartCard(long long b):balance_(b){if(b<0)throw invalid_argument("Negative balance");}long long balance()const{return balance_;}bool canTravel(long long f)const{return f>=0&&balance_>=MIN_BALANCE&&f<=balance_-MIN_BALANCE;}bool deduct(long long f){if(!canTravel(f))return false;balance_-=f;return true;}bool recharge(long long x){if(x<0||x>LLONG_MAX-balance_)return false;balance_+=x;return true;}};
#include <vector>
#include <string>
struct Case{string name;Zone z;int h;bool weekend;long long expected;};
int main(){vector<Case> tests={{"inner off",Zone::Inner,11,false,1000},{"middle off",Zone::Middle,11,false,2000},{"outer off",Zone::Outer,11,false,3000},{"inner peak",Zone::Inner,8,false,1200},{"middle peak",Zone::Middle,17,false,2400},{"outer peak",Zone::Outer,19,false,3600},{"08 boundary",Zone::Inner,8,false,1200},{"10 boundary",Zone::Inner,10,false,1000},{"17 boundary",Zone::Inner,17,false,1200},{"20 boundary",Zone::Inner,20,false,1000},{"weekend",Zone::Outer,8,true,2700},{"airport",Zone::Airport,11,false,6000}};int pass=0;for(const auto&t:tests){auto actual=fare(t.z,t.h,t.weekend);bool ok=actual==t.expected;pass+=ok;cout<<t.name<<" expected="<<t.expected<<" actual="<<actual<<" "<<(ok?"PASS":"FAIL")<<"\n";}SmartCard c(6000);bool exact=c.deduct(1000)&&c.balance()==5000;cout<<"exact Rs50 "<<(exact?"PASS":"FAIL")<<"\n";pass+=exact;bool denied=!c.deduct(1);cout<<"below Rs50 "<<(denied?"PASS":"FAIL")<<"\n";pass+=denied;bool negative=!c.recharge(-100);cout<<"negative recharge "<<(negative?"PASS":"FAIL")<<"\n";pass+=negative;try{fare(static_cast<Zone>(99),11);cout<<"unknown zone FAIL\n";}catch(const invalid_argument&){cout<<"unknown zone PASS\n";pass++;}cout<<"five-trip manual total expected=10800 actual="<<fare(Zone::Inner,11)+fare(Zone::Middle,11)+fare(Zone::Outer,11)+fare(Zone::Inner,8)+fare(Zone::Outer,19)<<"\n";cout<<"PASS "<<pass<<"/16\n";return pass==16?0:1;}
