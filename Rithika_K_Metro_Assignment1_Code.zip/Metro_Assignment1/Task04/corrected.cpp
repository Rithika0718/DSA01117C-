#include <iostream>
int main(){int a{7},b{2};double c{static_cast<double>(a/b)};double d{static_cast<double>(a)/static_cast<double>(b)};char ch{static_cast<char>('A'+2)};bool flag{static_cast<bool>(5)};unsigned u{1};int s{-1};std::cout<<c<<" "<<d<<"\n"<<ch<<" "<<static_cast<int>(ch)+1<<"\n"<<flag<<" "<<std::boolalpha<<flag<<"\n"<<(s<0||static_cast<unsigned>(s)<u?"s < u":"s >= u")<<"\n";}
